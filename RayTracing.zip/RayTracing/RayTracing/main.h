#pragma once

enum class textureType
{
	none,//�͗l�Ȃ�
	hstripe,//�Ȗ͗l(��)
	vstripe,//�Ȗ͗l(�c)
	checkered,//�s���͗l(�`�F�b�J�[�t���b�O)
	textured//�e�N�X�`���}�b�s���O
};

float Clamp(float Val, const float minVal, const float maxVal);

struct Color
{
	unsigned char r, g, b;
	Color() :r(0), g(0), b(0) {};
	Color(unsigned char inr, unsigned char ing, unsigned char inb) :r(inr), g(ing), b(inb) {};
	void operator*= (float scale)
	{
		r = Clamp(r*scale, 0, 255);
		g = Clamp(g*scale, 0, 255);
		b = Clamp(b*scale, 0, 255);
	}
	void operator+= (const Color& inCol)
	{
		r = Clamp(r + inCol.r, 0, 255);
		g = Clamp(g + inCol.g, 0, 255);
		b = Clamp(b + inCol.b, 0, 255);
	}
	Color operator + (const Color& inCol)const
	{
		Color ret(r, g, b);
		ret.r = Clamp(r + inCol.r, 0, 255);
		ret.g = Clamp(g + inCol.g, 0, 255);
		ret.b = Clamp(b + inCol.b, 0, 255);
		return ret;
	}
	Color operator * (const Color& inCol)const
	{
		Color ret(r, g, b);
		ret.r = Clamp(r * inCol.r, 0, 255);
		ret.g = Clamp(g * inCol.g, 0, 255);
		ret.b = Clamp(b * inCol.b, 0, 255);
		return ret;
	}
	Color operator / (const int& Col)const
	{
		Color ret(r, g, b);
		ret.r = Clamp(r / Col, 0, 255);
		ret.g = Clamp(g / Col, 0, 255);
		ret.b = Clamp(b / Col, 0, 255);
		return ret;
	}
	Color Max(const Color& col)
	{
		Color ret(r, g, b);
		ret.r = max(col.r, ret.r);
		ret.g = max(col.g, ret.g);
		ret.b = max(col.b, ret.b);
		return ret;
	}
};