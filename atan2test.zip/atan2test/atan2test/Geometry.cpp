#include <math.h>
#include "Geometry.h"

float Vector2::Magnitude() const
{
	return hypot(x,y);
}

Vector2 Vector2::Nomalized() const
{
	Vector2 ret = *this;
	auto m = Magnitude();
	ret.x /= m;
	ret.y /= m;
	return ret;
}

Vector2 Vector2::Scaled(const float val)const
{
	Vector2 ret= *this;
	ret.x *= val;
	ret.y *= val;
	return ret;
}

Vector2 Add(const Vector2 & lval, const Vector2 & rval)
{
	return Vector2((lval.x + rval.x), (lval.y + rval.y));
}

Vector2 Subtract(const Vector2 & lval, const Vector2 & rval)
{
	return Vector2((lval.x - rval.x), (lval.x - rval.x));
}
