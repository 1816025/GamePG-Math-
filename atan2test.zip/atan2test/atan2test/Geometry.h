#pragma once

struct Vector2
{
	float x;
	float y;
	Vector2() :x(0), y(0) {}
	Vector2(float inx, float iny) :x(inx), y(iny) {};
	float Magnitude()const;
	Vector2 Nomalized()const;
	Vector2 Scaled(float val)const;
};
using Position2 = Vector2;

Vector2 Add(const Vector2& lval, const Vector2& rval);
Vector2 Subtract(const Vector2& lval, const Vector2& rval);