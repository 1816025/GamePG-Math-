#include<DxLib.h>
#include<math.h>
#include "Geometry.h"

int WINAPI WinMain(HINSTANCE,HINSTANCE,LPSTR,int) {
	SetGraphMode(640, 480, 32);
	ChangeWindowMode(true);
	SetWindowText("atan2���K�T���v��");
	DxLib_Init();
	SetDrawScreen(DX_SCREEN_BACK);
	//�޲�Ʊ���
	SetDrawMode(DX_DRAWMODE_BILINEAR);
	auto arrowcatH=LoadGraph("img/arrowcat.png");

	Vector2 pos = { 320,240 };
	Vector2 v = { 0, 0 };
		auto mlastinput = 0;

	while (!ProcessMessage()) {
		ClearDrawScreen();
		
		int mx, my;
		GetMousePoint(&mx, &my);
		auto minput = GetMouseInput();
		auto angle = atan2(my - pos.y, mx - pos.x);
		if (minput&MOUSE_INPUT_LEFT)
		{
			//if (!(mlastinput&MOUSE_INPUT_LEFT))
			//{
				if (v.x == 0.0f && v.y == 0.0f)
				{
					v.x = cos(angle)*7;
					v.y = sin(angle)*7;
				}
				//else
				//{
				//	v.x = 0.0f;
				//	v.y = 0.0f;
				//}
			//}
		}
		else
		{
			v.x = 0.0f;
			v.y = 0.0f;
		}
		pos.x += v.x;
		pos.y += v.y;
		DrawRotaGraph(pos.x, pos.y, 1.0f, angle, arrowcatH,true);

		ScreenFlip();
	}
	DxLib_End();
}