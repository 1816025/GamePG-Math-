#include "Geometry.h"
#include<DxLib.h>
#include<algorithm>
void
Rect::Draw(unsigned int color) {
	DrawBox(Left(), Top(), Right(), Bottom(), color, true);
}
Vector2 operator*(const Vector2& lval, const Vector2& rval) {
	return Vector2(lval.x*rval.x, lval.y*rval.y);
}
bool 
IsCollided(const Rect& lval, const Rect& rval ,Size& overlappedSize) {
	bool ret = false;
	 
	return !((lval.Right() < rval.Left()) || (rval.Right() < lval.Left())
		   ||(lval.Bottom() < rval.Top()) || (rval.Bottom() < lval.Top()));
}
